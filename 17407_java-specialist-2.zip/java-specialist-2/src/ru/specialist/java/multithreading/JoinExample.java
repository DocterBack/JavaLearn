package ru.specialist.java.multithreading;

public class JoinExample {

    public static void main(String[] args) throws InterruptedException {

        Thread t0 = new Thread(() -> {
            for (int i = 1; i <= 1000; i++) {
                System.out.printf("%s: %d\n", Thread.currentThread().getName(), i);
            }
        });

        Thread t1 = new Thread(() -> {
            try {
                t0.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.printf("%s: Completed\n", Thread.currentThread().getName());
        });

        Thread.sleep(1000);
        t0.start();
        Thread.sleep(1);
        t1.start();

    }
}
