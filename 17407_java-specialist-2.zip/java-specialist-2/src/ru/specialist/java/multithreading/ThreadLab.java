package ru.specialist.java.multithreading;

import java.util.Scanner;

public class ThreadLab {

    // example 1
    public static class Counter extends Thread {

        private int n;

        public Counter(int n) {
            this.n = n;
        }

        @Override
        public void run() {
            for (int i = 1; i <= n; i++) {
                System.out.printf("%s %d\n", Thread.currentThread().getName(), i);
            }
        }
    }

    public static void main(String[] args) {

        int n0, n1;

        try (Scanner scanner = new Scanner(System.in)){
            n0 = scanner.nextInt();
            n1 = scanner.nextInt();
        }

//         example 1
//        new Counter(n0).start();
//        new Counter(n1).start();

//        example 2
        new Thread(getRunnable(n0)).start();
        new Thread(getRunnable(n1)).start();

    }

    private static Runnable getRunnable(int n){
        return () -> {
            for (int i = 1; i <= n; i++) {
                System.out.printf("%s %d\n", Thread.currentThread().getName(), i);
            }
        };
    }


}
