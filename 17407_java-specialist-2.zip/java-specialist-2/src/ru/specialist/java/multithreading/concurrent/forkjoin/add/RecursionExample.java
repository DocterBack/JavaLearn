package ru.specialist.java.multithreading.concurrent.forkjoin.add;

public class RecursionExample {

    public static void main(String[] args) {
        int result = sum(1, 10);
        System.out.println(result);
    }

    private static int sum (int i, int level){
        if (level == 0)
            return i;
        else
            return sum(i + 1, level - 1);
    }
}
