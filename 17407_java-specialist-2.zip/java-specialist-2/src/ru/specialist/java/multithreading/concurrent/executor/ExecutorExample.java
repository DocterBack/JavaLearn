package ru.specialist.java.multithreading.concurrent.executor;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class ExecutorExample {

    private static class Sum implements Callable<Integer> {
        @Override
        public Integer call() throws Exception {
            System.out.printf("%s: Calculating 1\n", Thread.currentThread().getName());
            Thread.sleep(1000);
            return 2 + 2;
        }
    }

    public static void main(String[] args) throws ExecutionException, InterruptedException {
        ExecutorService pool = Executors.newSingleThreadExecutor();
        Future<Integer> future1 = pool.submit(new Sum());
        Future<Integer> future2 = pool.submit(() -> {
            System.out.printf("%s: Calculating 2\n", Thread.currentThread().getName());
            Thread.sleep(1000);
            return 5 + 5;
        });
        Future<Integer> future3 = pool.submit(() -> {
            System.out.printf("%s: Calculating 2\n", Thread.currentThread().getName());
            Thread.sleep(1000);
            return 10 + 10;
        });

        future1.cancel(true);

        pool.shutdown();
//        pool.shutdownNow();
//        Integer res = future.get();

        while (!future1.isDone() || !future2.isDone() || !future3.isDone()){
            System.out.printf("%s: Waiting for result\n", Thread.currentThread().getName());
            Thread.sleep(100);
        }

        if (!future1.isCancelled())
            System.out.printf("Result 1 = %d\n", future1.get());
        if (!future2.isCancelled())
            System.out.printf("Result 2 = %d\n", future2.get());
        if (!future3.isCancelled())
            System.out.printf("Result 3 = %d\n", future3.get());

        List<Future<Long>> tasks = new ArrayList<>();

        //in loop:
        //  Future<Long> task = pool.submit
        //  tasks.add(task);

        long sum = 0;
        for (Future<Long> task : tasks) {
            sum += task.get();
        }

        //sum - result


    }
}
