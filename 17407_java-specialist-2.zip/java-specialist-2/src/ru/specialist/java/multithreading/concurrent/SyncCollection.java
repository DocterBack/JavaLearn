package ru.specialist.java.multithreading.concurrent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class SyncCollection {

    public static void main(String[] args) throws InterruptedException {

        List<Integer> list =
//                new ArrayList<>();
//                Collections.synchronizedList(new ArrayList<>());
                new CopyOnWriteArrayList<>();
        List<Integer> subList = IntStream
                .rangeClosed(1, 100)
                .boxed()
                .collect(Collectors.toList());
        Runnable listAdd = () -> list.addAll(subList);

        Thread t1 = new Thread(listAdd);
        Thread t2 = new Thread(listAdd);

        t1.start();
        t2.start();

        t1.join();
        t2.join();

        System.out.println(list.size());

    }
}
