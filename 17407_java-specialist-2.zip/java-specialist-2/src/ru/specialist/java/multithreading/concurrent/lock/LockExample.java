package ru.specialist.java.multithreading.concurrent.lock;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class LockExample {

    private static int count;

    private static final Lock lock = new ReentrantLock();

    public static void main(String[] args) throws InterruptedException {
        Thread t0 = new Thread(() -> {
            for (int i = 0; i < 100000000; i++) {
                while (!lock.tryLock()){
                    try{
                        System.out.printf("%s: Waiting for a lock...\n", Thread.currentThread().getName());
                        Thread.sleep(100);
                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }
                }
                count++;

                lock.unlock();
            }
        });

        Thread t1 = new Thread(() -> {
            for (int i = 0; i < 100000000; i++) {
                while (!lock.tryLock()){
                    try{
                        System.out.printf("%s: Waiting for a lock...\n", Thread.currentThread().getName());
                        Thread.sleep(100 );
                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }
                }
                count--;

                lock.unlock();
            }
        });

        t0.start();
        t1.start();

        t0.join();
        t1.join();

        System.out.println(count);
    }

}
