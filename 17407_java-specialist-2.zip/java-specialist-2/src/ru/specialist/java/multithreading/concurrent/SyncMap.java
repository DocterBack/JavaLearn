package ru.specialist.java.multithreading.concurrent;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class SyncMap {

    public static void main(String[] args) throws InterruptedException {
        Map<Integer, String> map =
//          new HashMap<>();
//            Collections.synchronizedMap(new HashMap<>());
                new ConcurrentHashMap<>();

        Thread t1 = new Thread(() -> IntStream
                .rangeClosed(1, 100)
                .forEach(x -> map.put(x, Integer.toString(x))));
        Thread t2 = new Thread(() -> IntStream
                .rangeClosed(2, 200)
                .forEach(x -> map.put(x, Integer.toString(x))));

        t1.start();
        t2.start();

        t1.join();
        t2.join();

        System.out.println(map.size());
    }

}
