package ru.specialist.java.multithreading;

public class WaitNotifyLab2 {
    static int arg = 3;
    static final Object  monitor = new Object();

    public static void main(String[] args) throws InterruptedException  {

        Thread t0 = new Thread( () -> {
            for (int i = 0; i < 100 ; i++) {
                synchronized (monitor) {
                        arg = arg*arg;
                        System.out.println("Попытка потока t0 номер " + i + ", значение arg = " + arg);
                        monitor.notify();
                        if (i == 99)
                            continue;
                        try {
                            monitor.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                }
            }

        }
        );

        Thread t1 = new Thread( () -> {
            for (int i = 0; i < 100 ; i++) {
                synchronized (monitor) {
                    arg = (int)Math.sqrt(arg);
                    System.out.println("Попытка потока t1 номер " + i + ", значение arg = " + arg);
                    monitor.notify();
                    if (i == 99)
                        continue;
                    try {
                        monitor.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }

        }
        );

        t0.start();
        Thread.sleep(10);
        t1.start();
    }

}