package ru.specialist.java.multithreading.concurrent.lock;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ConditionCountExample {

    private static final Lock lock = new ReentrantLock();

    private static final Condition cond1 = lock.newCondition();
    private static final Condition cond2 = lock.newCondition();

    private static int n;

    public static void main(String[] args) throws InterruptedException {

        Thread t0 = new Thread(() -> {
            for (int i = 1; i <= 500; i++) {
                lock.lock();
                n++;
                System.out.printf("%s: %d\n", Thread.currentThread().getName(), n);
                if (i == 100)
                    cond1.signal();
                if (i == 200)
                    cond2.signal();
                lock.unlock();
            }

        });

        Thread t1 = new Thread(() -> {
            lock.lock();
            try {
                cond1.await();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                lock.unlock();
            }

            for (int i = 1; i <= 400; i++) {
                lock.lock();
                n--;
                System.out.printf("%s: %d\n", Thread.currentThread().getName(), n);
                lock.unlock();
            }

        });


        Thread t2 = new Thread(() -> {
            lock.lock();
            try {
                cond2.await();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                lock.unlock();
            }

            for (int i = 1; i <= 100; i++) {
                lock.lock();
                n--;
                System.out.printf("%s: %d\n", Thread.currentThread().getName(), n);
                lock.unlock();
            }
        });

        t1.start();
        Thread.sleep(100);

        t2.start();
        Thread.sleep(100);

        t0.start();


        t0.join();
        t1.join();
        t2.join();

        System.out.println(n);
    }

}
