package ru.specialist.java.multithreading.concurrent.executor;

import java.util.concurrent.*;

public class ExecutorExample {

    private static class Sum implements Callable<Integer> {

        @Override
        public Integer call() throws Exception {
            System.out.printf("%s: Calculating 2 + 2\n", Thread.currentThread().getName());
            Thread.sleep(1000);
            return 2 + 2;
        }
    }

    public static void main(String[] args) throws ExecutionException, InterruptedException {
//        ExecutorService pool = Executors.newSingleThreadExecutor();
        int n = Runtime.getRuntime().availableProcessors();
//        ExecutorService pool = Executors.newFixedThreadPool(n);
        ExecutorService pool = Executors.newCachedThreadPool();
        Future<Integer> result1 = pool.submit(new Sum());
        Future<Integer> result2 = pool.submit(() -> {
            System.out.printf("%s: Calculating 5 + 5\n", Thread.currentThread().getName());
            Thread.sleep(1000);
            return 5 + 5;
        });
        Future<Integer> result3 = pool.submit(() -> {
            System.out.printf("%s: Calculating 10 + 10\n", Thread.currentThread().getName());
            Thread.sleep(1000);
            return 10 + 10;
        });
        pool.shutdown();

//        pool.shutdownNow();

        result1.cancel(true);

        while (!result1.isDone() || !result2.isDone() || !result3.isDone()){
            System.out.println("Waiting for results...");
            Thread.sleep(100);
        }
        if (!result1.isCancelled())
            System.out.println("Result1: " + result1.get());
        if (!result2.isCancelled())
            System.out.println("Result2: " + result2.get());
        if (!result3.isCancelled())
            System.out.println("Result3: " + result3.get());

        System.out.println("End");
    }
}
