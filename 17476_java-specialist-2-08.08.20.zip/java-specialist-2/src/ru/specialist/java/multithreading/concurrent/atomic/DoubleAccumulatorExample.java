package ru.specialist.java.multithreading.concurrent.atomic;

import java.util.concurrent.atomic.DoubleAccumulator;
import java.util.concurrent.atomic.DoubleAdder;

public class DoubleAccumulatorExample {

    private static final DoubleAccumulator val = new DoubleAccumulator((mult, n) -> mult = mult * n, 1);

    public static void main(String[] args) throws InterruptedException {
        Runnable task = () -> {
            for (int i = 1; i <= 10; i++) {
                val.accumulate(i);
            }
        };

        Thread t0 = new Thread(task);
        Thread t1 = new Thread(task);

        t0.start();
        t1.start();

        t0.join();
        t1.join();

        System.out.println(val);
    }
}
