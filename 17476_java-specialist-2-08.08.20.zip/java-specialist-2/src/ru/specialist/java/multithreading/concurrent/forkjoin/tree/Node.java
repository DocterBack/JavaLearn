package ru.specialist.java.multithreading.concurrent.forkjoin.tree;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class Node {

    private long value;
    private List<Node> children = Collections.emptyList();

    public Collection<Node> getChildren(){
        return children;
    }

    public Node (long value){
        this.value = value;
    }

    public long getValue(){
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public void setChildren(List<Node> children) {
        this.children = children;
    }

    @Override
    public String toString() {
        return toString(0);
    }

    private String toString(int level){
        StringBuilder sb = new StringBuilder();

        sb = sb.append("\t".repeat(Math.max(0, level))).append(value).append("\n");

        for (Node n : children) {
            sb.append(n.toString(level + 1));
        }

        return sb.toString();
    }
}