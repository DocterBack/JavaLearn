package ru.specialist.java.multithreading.concurrent.executor;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class SumLab {

    public static void main(String[] args) throws ExecutionException, InterruptedException {

        sum(1, 1000000000L);

        long t1 = System.currentTimeMillis();
        long sum2 = sumMultiThread(1000000000L, 4);
        long t2 = System.currentTimeMillis();
        System.out.println(sum2);
        System.out.printf("Completed in %d ms\n", t2 - t1);

        t1 = System.currentTimeMillis();
        long sum1 = sum(1, 1000000000L);
        t2 = System.currentTimeMillis();
        System.out.println(sum1);
        System.out.printf("Completed in %d ms\n", t2 - t1);
    }

    private static long sum(long from, long to){
        long sum = 0;
        for (long i = from; i <= to ; i++) {
            sum += i;
        }
        return sum;
    }

    private static long sumMultiThread(long to, int nTasks) throws ExecutionException, InterruptedException {
        ExecutorService pool = Executors.newCachedThreadPool();

        List<Future<Long>> tasks = new ArrayList<>();
        long stepSize = to/nTasks;
        long r = to % nTasks;

        for (int i = 0; i < nTasks; i++) {
            long a = i*stepSize + 1;
            long b = i*stepSize + stepSize + (i == nTasks - 1 ? r : 0);
            tasks.add(pool.submit(() -> sum(a, b)));
        }
        pool.shutdown();

        long sum = 0;
        for (Future<Long> task : tasks){
            sum += task.get();
        }

        return sum;
    }
}
