package ru.specialist.java.multithreading;

public class StringBuilderBuffer {

    public static void main(String[] args) throws InterruptedException {
//        StringBuilder builder = new StringBuilder();
        StringBuffer buffer = new StringBuffer();

        Thread t0 = new Thread(() -> {
            for (int i = 1; i <= 100; i++) {
//                builder.append(i + ", ");
                buffer.append(i + ", ");
            }
        });

        Thread t1 = new Thread(() -> {
            for (int i = 101; i <= 200; i++) {
//                builder.append(i + ", ");
                buffer.append(i + ", ");
            }
        });

        t0.start();
        t1.start();

        t0.join();
        t1.join();

//        System.out.println(builder);
        System.out.println(buffer);

    }

}
