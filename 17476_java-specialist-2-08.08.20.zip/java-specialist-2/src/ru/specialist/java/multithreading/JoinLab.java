package ru.specialist.java.multithreading;

import java.util.Scanner;

public class JoinLab {

    public static void main(String[] args) throws InterruptedException {

        int n0, n1, n2;

        try (Scanner scanner = new Scanner(System.in)){
            n0 = scanner.nextInt();
            n1 = scanner.nextInt();
            n2 = scanner.nextInt();
        }

        Thread t0 = new Thread(() -> loop(n0));

        Thread t1 = new Thread(() -> {
            try {
                t0.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            loop(n1);
        });

        t0.start();
        Thread.sleep(1L);
        t1.start();

        t1.join();
        loop(n2);

    }

    private static void loop(int n){
        for (int i = 1; i <= n; i++) {
            System.out.printf("%s %d\n", Thread.currentThread().getName(), i);
        }
    }

}
