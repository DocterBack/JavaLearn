package ru.specialist.java.jdbc;

import java.sql.*;
import java.util.Scanner;

public class JdbcExample {

    private static final String URL = "jdbc:postgresql://localhost:5432/postgres";
    private static final String LOGIN = "postgres";
    private static final String PASSWORD = "postgres";

    public static void main(String[] args) throws ClassNotFoundException, SQLException {

        try (Connection c = DriverManager.getConnection(URL, LOGIN, PASSWORD);
             Scanner scanner = new Scanner(System.in)){

            String param = scanner.nextLine();


//         SQL Injection
/*         Statement statement = c.createStatement();
           ResultSet set = statement.executeQuery("select book_id, title " +
                                                            "from books " +
                                                            "where title like '%" + param + "%'");*/

            PreparedStatement statement = c.prepareStatement("select book_id, title " +
                    "from books " +
                                                                 "where title like ? and title like ?");
            statement.setString(1, "%" + param + "%");
            param = scanner.nextLine();
            statement.setString(2, "%" + param + "%");
            ResultSet set = statement.executeQuery();

            while (set.next()){
//                int bookId = set.getInt(1);
                int bookId = set.getInt("book_id");
//                String title = set.getString(2);
                String title = set.getString("title");

                System.out.printf("Book: %d, %s\n", bookId, title);
            }



        }
    }

}
