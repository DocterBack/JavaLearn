package ru.specialist.java.jdbc;

import java.sql.*;

public class FunctionExample {

    private static final String URL = "jdbc:postgresql://localhost:5432/postgres";
    private static final String LOGIN = "postgres";
    private static final String PASSWORD = "postgres";

    public static void main(String[] args) throws ClassNotFoundException, SQLException {

        try (Connection c = DriverManager.getConnection(URL, LOGIN, PASSWORD)){
            CallableStatement call = c.prepareCall("{? = call inc(?)}");
            call.registerOutParameter(1, Types.INTEGER);
            call.setInt(2, 9);
            call.execute();

            System.out.println(call.getInt(1));

            System.out.println("---");

            call = c.prepareCall("{? = call insert_author_returning_key(?, ?)}");
            call.registerOutParameter(1, Types.INTEGER);
            call.setString(2, "Vasya");
            call.setString(3, "Petrov");
            call.execute();
            System.out.println(call.getInt(1));

        }
    }

}
