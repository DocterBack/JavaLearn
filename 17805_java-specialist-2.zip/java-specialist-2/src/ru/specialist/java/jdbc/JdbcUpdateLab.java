package ru.specialist.java.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class JdbcUpdateLab {

    private static final String URL = "jdbc:postgresql://localhost:5432/postgres";
    private static final String LOGIN = "postgres";
    private static final String PASSWORD = "postgres";

    public static void main(String[] args) throws ClassNotFoundException, SQLException {

        try (Connection c = DriverManager.getConnection(URL, LOGIN, PASSWORD);
             Scanner scanner = new Scanner(System.in)){
            PreparedStatement statement = c.prepareStatement("insert into authors " +
                    "(author_name, last_name) values (?, ?)");
            System.out.println("Enter author name:");
            String param = scanner.nextLine();
            statement.setString(1, param);

            System.out.println("Enter author last name:");
            param = scanner.nextLine();
            statement.setString(2, param);

            statement.executeUpdate();

        }
    }

}
