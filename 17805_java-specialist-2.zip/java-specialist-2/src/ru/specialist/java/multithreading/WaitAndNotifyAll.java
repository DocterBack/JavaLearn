package ru.specialist.java.multithreading;

public class WaitAndNotifyAll {

    public static void main(String[] args) {
        Object monitor = new Object();

        Runnable runnable = () -> {
            synchronized (monitor){
                System.out.printf("%s: Waiting\n", Thread.currentThread().getName());
                try{
                    monitor.wait(3000);
                } catch (InterruptedException e){
                    e.printStackTrace();
                }
                System.out.printf("%s: Completed\n", Thread.currentThread().getName());
            }
        };

        new Thread(runnable).start();
        new Thread(runnable).start();
        new Thread(runnable).start();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        synchronized (monitor){
            System.out.printf("%s: Notifying\n", Thread.currentThread().getName());
//            monitor.notify();
            monitor.notifyAll();
        }
    }
}
