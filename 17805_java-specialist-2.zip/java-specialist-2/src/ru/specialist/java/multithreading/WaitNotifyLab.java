package ru.specialist.java.multithreading;

import java.util.function.Function;

public class WaitNotifyLab {

    private static double count = 3;

    private final static Object monitor = new Object();

    public static void main(String[] args) throws InterruptedException {
        Thread t0 = new Thread(getRunnable(p -> p*p));
        Thread t1 = new Thread(getRunnable(Math::sqrt));

        t0.start();
        Thread.sleep(10);
        t1.start();
    }

    private static Runnable getRunnable(Function<Double, Double> function){
        return () -> {
            for (int i = 0; i < 10; i++) {
                synchronized (monitor) {
                    count = function.apply(count);
                    System.out.println("count: " + count);

                    monitor.notify();
                    if (i == 9)
                        return;
                    try {
                        monitor.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
    }

}