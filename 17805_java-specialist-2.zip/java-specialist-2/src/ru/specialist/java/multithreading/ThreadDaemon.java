package ru.specialist.java.multithreading;

public class ThreadDaemon {

    public static void main(String[] args) throws InterruptedException {
        Thread t = new Thread(() -> {
            for (int i = 1; i <= 100; i++) {
                System.out.println(i);
            }
        });

        t.setDaemon(true);
        t.start();

        Thread.sleep(1);
    }
}
