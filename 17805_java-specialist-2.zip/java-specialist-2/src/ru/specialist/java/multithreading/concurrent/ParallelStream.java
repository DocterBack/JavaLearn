package ru.specialist.java.multithreading.concurrent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.LongStream;

public class ParallelStream {

    public static void main(String[] args) {
        List<Integer> list = new ArrayList<>();

        list.add(1);
        list.add(5);
        list.add(2);
        list.add(8);
        list.add(3);
        list.add(4);
        list.add(7);

        List<Integer> filteredList = new ArrayList<>();
        System.out.println(list);
        for (Integer i : list) {
            if (i > 4)
                filteredList.add(i);
        }

        System.out.println(filteredList);

        Collections.sort(filteredList);

        System.out.println(filteredList);

        List<Integer> sortedList = list.stream()
                .filter(i -> i > 4)
                .sorted()
                .collect(Collectors.toList());

        System.out.println(sortedList);

        long t1 = System.currentTimeMillis();
        long sum = LongStream.rangeClosed(0, 1000000000)
                .sum();
        long t2 = System.currentTimeMillis();
        System.out.println(sum);
        System.out.printf("Completed in %d ms\n", t2 - t1);

        t1 = System.currentTimeMillis();
        sum = LongStream.rangeClosed(0, 1000000000)
                .parallel()
                .sum();
        t2 = System.currentTimeMillis();
        System.out.println(sum);
        System.out.printf("Completed in %d ms\n", t2 - t1);




    }
}
