package ru.specialist.java.multithreading.concurrent.atomic;

import java.util.concurrent.atomic.AtomicReference;
import java.util.function.IntUnaryOperator;
import java.util.function.UnaryOperator;

public class AtomicReferenceExample {

    private static final AtomicReference<Double> val = new AtomicReference<>(1d);

    public static void main(String[] args) throws InterruptedException {
        Thread t0 = new Thread(() -> calc(n -> n * 2));
        Thread t1 = new Thread(() -> calc(n -> n / 2));

        t0.start();
        t1.start();

        t0.join();
        t1.join();

        System.out.println(val);

    }

    private static void calc(UnaryOperator<Double> operator){
        for (int i = 0; i < 1000; i++) {
            val.updateAndGet(operator);
        }
    }

}


