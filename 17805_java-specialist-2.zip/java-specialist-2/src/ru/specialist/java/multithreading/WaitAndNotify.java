package ru.specialist.java.multithreading;

public class WaitAndNotify {

    private static final Object monitor = new Object();

    public static void main(String[] args) throws InterruptedException {

        Thread t1 = new Thread(() -> {
            synchronized (monitor){
                try {
                    System.out.printf("%s: Waiting\n", Thread.currentThread().getName());
                    monitor.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.printf("%s: Completed\n", Thread.currentThread().getName());
            }
        });

        Thread t0 = new Thread(() -> {
            for (int i = 1; i <= 100; i++) {
                System.out.println(i);
                if (i == 50) {
                    synchronized (monitor) {
                        monitor.notify();
                    }
                }
            }
        });

        t1.start();
        Thread.sleep(100);
        t0.start();
    }
}
