package ru.specialist.java.multithreading;

import java.util.Scanner;

public class ThreadExample {

    public static class Counter extends Thread {

        @Override
        public void run() {
            for (int i = 1; i <= 10; i++) {
                System.out.printf("%s %d\n", Thread.currentThread().getName(), i);
            }
        }
    }

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();

        Thread t0 = new Counter();
//        Counter t1 = new Counter();


        Thread t2 = new Thread(() -> {
            for (int i = 1; i <= 10; i++) {
                System.out.printf("%s %d\n", Thread.currentThread().getName(), i);
            }
        });

        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 1; i <= 10; i++) {
                    System.out.printf("%s %d\n", Thread.currentThread().getName(), i);
                }
            }
        });


        t0.start();
        t1.start();
        t2.start();

    }

}
