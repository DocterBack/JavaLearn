package ru.specialist.java.multithreading;

public class InterruptExample {

    public static void main(String[] args) throws InterruptedException {
        Thread t = new Thread(() -> {
            for (int i = 1; i <= 1000000 ; i++) {
                if (Thread.interrupted())
                    return;
                System.out.printf("%s: %d\n", Thread.currentThread().getName(), i);
            }

//            Thread.currentThread().interrupt();

/*            if (Thread.interrupted()){
                System.out.println("Thread is interrupted!!!!");
                return;
            }*/

/*            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
//                e.printStackTrace();
                return;
            }*/

            for (int i = 11; i <= 20 ; i++) {
                System.out.printf("%s: %d\n", Thread.currentThread().getName(), i);
            }

        });

        t.start();
        Thread.sleep(100L);
        t.interrupt();
    }
}
