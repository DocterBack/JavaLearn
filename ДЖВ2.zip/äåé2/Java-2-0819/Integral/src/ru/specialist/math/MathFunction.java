package ru.specialist.math;

public interface MathFunction
{
	double function(double x);
}
