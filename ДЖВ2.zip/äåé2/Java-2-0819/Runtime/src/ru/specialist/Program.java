package ru.specialist;

import java.io.IOException;

public class Program
{

	public static void main(String[] args) 
			throws IOException
	{
		Runtime.getRuntime().exec(
				"\"C:\\Program Files\\Microsoft Office\\Office15\\winword.exe\"");
		

	}

}
