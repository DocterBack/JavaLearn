
public class Sync {
	public volatile double x = 1.0;
	public volatile boolean isSin = true;

}
