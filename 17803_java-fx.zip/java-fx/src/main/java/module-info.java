module ru.specialist.java.fx {
    requires javafx.controls;
    requires javafx.fxml;

    opens ru.specialist.java.fx to javafx.fxml;
    exports ru.specialist.java.fx;
}