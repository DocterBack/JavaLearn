package ru.specialist.java.jdbc;

import java.sql.*;
import java.util.Scanner;

public class FunctionLab {

    private static final String URL = "jdbc:postgresql://localhost:5432/postgres";
    private static final String LOGIN = "postgres";
    private static final String PASSWORD = "postgres";

    public static void main(String[] args) throws ClassNotFoundException, SQLException {

        try (Connection c = DriverManager.getConnection(URL, LOGIN, PASSWORD);
             Scanner scanner = new Scanner(System.in))
        {
            CallableStatement call = c.prepareCall("{? = call insert_author_and_book(?, ?, ?)}");
            call.registerOutParameter(1, Types.INTEGER);

            System.out.println("Enter author name:");
            String fistName = scanner.nextLine();

            System.out.println("Enter author last name:");
            String lastName = scanner.nextLine();

            System.out.println("Enter book title:");
            String title = scanner.nextLine();

            call.setString(2, fistName);

            call.setString(3, lastName);

            call.setString(4, title);
            call.execute();
            System.out.println(call.getInt(1));

        }
    }

}
