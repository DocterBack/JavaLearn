package ru.specialist.java.multithreading;

public class SynchronizedExample {

    private static final Object monitor = new Object();

    private static int count = 0;

    public static void main(String[] args) throws InterruptedException {

//        SynchronizedExample object = new SynchronizedExample();

        Object monitor = new Object();

        Thread t0 = new Thread(() -> {
            for (int i = 0; i < 100000; i++) {
                //monitor lock
                synchronized (monitor) {
                    System.out.printf("%s: %d\n", Thread.currentThread().getName(), count++);
                }
//                object.inc();
                //monitor unlock
            }
        });

        Thread t1 = new Thread(() -> {
            for (int i = 0; i < 100000; i++) {
                //monitor lock
                synchronized (monitor) {
                    System.out.printf("%s: %d\n", Thread.currentThread().getName(), count--);
                }
//                object.dec();
                //monitor unlock
            }
        });

        t0.start();
        t1.start();

        t1.join();
        t0.join();

        System.out.println(count);
    }

    private synchronized void inc(){
        count++;
    }

    private synchronized void dec(){
        count--;
    }


}
