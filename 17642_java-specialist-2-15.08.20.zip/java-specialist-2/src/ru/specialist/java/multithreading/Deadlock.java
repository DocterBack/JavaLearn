package ru.specialist.java.multithreading;

public class Deadlock {

    public static void main(String[] args) throws InterruptedException {

        Object a = new Object();
        Object b = new Object();

        new Thread(() -> {
            synchronized (a){
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                synchronized (b){

                }
            }
        }).start();

        Thread.sleep(100);

        new Thread(() -> {
            synchronized (b){
                synchronized (a){

                }
            }
        }).start();

    }
}
