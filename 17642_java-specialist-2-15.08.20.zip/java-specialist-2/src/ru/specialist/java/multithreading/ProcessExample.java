package ru.specialist.java.multithreading;

import java.io.IOException;

public class ProcessExample {

    public static void main(String[] args) throws IOException {
        System.out.println(Runtime.getRuntime().availableProcessors());
        Runtime.getRuntime().gc();
//        Runtime.getRuntime().exec("explorer.exe");
    }
}
