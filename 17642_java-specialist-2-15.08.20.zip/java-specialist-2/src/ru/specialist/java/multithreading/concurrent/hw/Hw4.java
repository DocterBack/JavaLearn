package ru.specialist.java.multithreading.concurrent.hw;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Hw4 {
    public static void main(String[] args) {
        String fileName;

        Scanner scanner;
        scanner = new Scanner(System.in);
        fileName = scanner.nextLine().trim();

//        fileName = "D:\\JavaProjects\\IntelliJ IDEA Projects\\lab22\\src\\2";
        long count;
        long startTime;
        long endTime;
        List<String> lines;

        count = 0;
        startTime = System.currentTimeMillis();
        try {
            lines = Files.readAllLines(Paths.get(fileName));

            System.out.println("Однопоточное решение.");
            startTime = System.currentTimeMillis();
            for (String line : lines) {
                long commasInLine = commasCounter(line);
                count += commasInLine;
            }
            endTime = System.currentTimeMillis();

            System.out.printf("Всего: %d запятых%n", count);
            System.out.printf("Время выполнения: %d%n", endTime - startTime);
            System.out.println("---------------------------------");

            System.out.println("Решение1 с помощью Stream API.");
            startTime = System.currentTimeMillis();
            count = lines.stream()
                    .parallel()
                    .mapToLong(Hw4::commasCounter).sum();
            endTime = System.currentTimeMillis();

            System.out.printf("Всего: %d запятых%n", count);
            System.out.printf("Время выполнения: %d%n", endTime - startTime);
            System.out.println("---------------------------------");

            Map<Integer, Long> mapper = new TreeMap<>();
            for (int i = 1; i <= 100; i++) {
                System.out.printf("Решение1 с помощью Executors. %d нитей.%n", i);
                String text = String.join(" ", lines);
                startTime = System.currentTimeMillis();
                count = executorMethod(text, i);
                endTime = System.currentTimeMillis();

                long time = endTime - startTime;
                mapper.put(i, time);
                System.out.printf("Всего: %d запятых%n", count);
                System.out.printf("Время выполнения: %d%n", time);
                System.out.println("---------------------------------");
            }
            long minValue = Long.MAX_VALUE;
            int minKey = 0;
            for (Map.Entry<Integer, Long> entry : mapper.entrySet()) {
                long currentValue = entry.getValue();
                if (currentValue < minValue) {
                    minValue = currentValue;
                    minKey = entry.getKey();
                }
            }
            System.out.printf("При %d нитях время выполнения %d%n", minKey, minValue);
            Map.Entry<Integer, Long> minEntry = Collections.min(mapper.entrySet(), Map.Entry.comparingByValue());
            System.out.printf("При %d нитях время выполнения %d%n", minEntry.getKey(), minEntry.getValue());


            System.out.println("Решение2 с помощью Executors.");
            startTime = System.currentTimeMillis();
            count = executorMethod2(lines);
            endTime = System.currentTimeMillis();

            System.out.printf("Всего: %d запятых%n", count);
            System.out.printf("Время выполнения: %d%n", endTime - startTime);
            System.out.println("---------------------------------");

            mapper = new TreeMap<>();
            for (int i = 1; i <= 100; i++) {
                System.out.printf("Решение с помощью Thread. %d нитей.%n", i);
                String text = String.join(" ", lines);
                startTime = System.currentTimeMillis();
                count = threadMethod(text, i);
                endTime = System.currentTimeMillis();
                long time = endTime - startTime;
                mapper.put(i, time);
                System.out.printf("Всего: %d запятых%n", count);
                System.out.printf("Время выполнения: %d%n", time);
                System.out.println("---------------------------------");
            }
            minValue = Long.MAX_VALUE;
            minKey = 0;
            for (Map.Entry<Integer, Long> entry : mapper.entrySet()) {
                long currentValue = entry.getValue();
                if (currentValue < minValue) {
                    minValue = currentValue;
                    minKey = entry.getKey();
                }
            }
            System.out.printf("При %d нитях время выполнения %d%n", minKey, minValue);
            minEntry = Collections.min(mapper.entrySet(), Map.Entry.comparingByValue());
            System.out.printf("При %d нитях время выполнения %d%n", minEntry.getKey(), minEntry.getValue());
//            System.out.println("Решение с помощью .");
//            startTime = System.currentTimeMillis();
//            // TODO: 12.08.20
//            endTime = System.currentTimeMillis();
//            System.out.printf("Всего: %d запятых%n", count);
//            System.out.printf("Время выполнения: %d%n", endTime - startTime);
//            System.out.println("---------------------------------");

        } catch (IOException | ExecutionException | InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Решение2 с помощью Stream API.");
        startTime = System.currentTimeMillis();
        try {
            long commaCount = Files.lines(Paths.get(fileName))
                    .parallel()
                    .mapToLong(Hw4::commasCounter).sum();
            endTime = System.currentTimeMillis();

            System.out.printf("Всего: %d запятых%n", commaCount);
            System.out.printf("Время выполнения: %d%n", endTime - startTime);
            System.out.println("---------------------------------");
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private static long commasCounter(String text) {
        return text.chars().filter(ch -> ch == ',').count();
    }

    private static long commasCounter2(String text) {
        long counter = 0;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == ',') {
                counter++;
            }
        }
        return counter;
    }

    private static long executorMethod(String text, int nTasks) throws ExecutionException, InterruptedException {
        ExecutorService pool = Executors.newCachedThreadPool();
        int textLength = text.length();
        List<Future<Long>> tasks = new ArrayList<>();
        int stepSize = textLength / nTasks;
        int r = textLength % nTasks;

        for (int i = 0; i < nTasks; i++) {
            int a = i * stepSize;
            int b = a + stepSize + (i == nTasks - 1 ? r : 0);
            tasks.add(pool.submit(() -> commasCounter(text.substring(a, b))));
        }
        pool.shutdown();

        long sum = 0;
        for (Future<Long> task : tasks) {
            sum += task.get();
        }
        return sum;
    }

    private static long executorMethod2(List<String> lines) throws ExecutionException, InterruptedException {
        ExecutorService pool = Executors.newCachedThreadPool();
        List<Future<Long>> tasks = new ArrayList<>();
        for (String line : lines) {
            tasks.add(pool.submit(() -> commasCounter(line)));
        }
        pool.shutdown();

        long sum = 0;
        for (Future<Long> task : tasks) {
            sum += task.get();
        }

        return sum;
    }

    private static long threadMethod(String text, int nTasks) throws InterruptedException {
        int textLength = text.length();
        int stepSize = textLength / nTasks;
        int r = textLength % nTasks;
        long sum = 0;
        List<Thread> threads = new ArrayList<>();
        List<Long> sums = new ArrayList<>();
        for (int i = 0; i < nTasks; i++) {
            int a = i * stepSize;
            int b = a + stepSize + (i == nTasks - 1 ? r : 0);
            threads.add(new Thread(() -> sums.add(commasCounter(text.substring(a, b)))));
        }
        for (Thread t : threads) {
            t.start();
        }
        for (Thread t : threads) {
            t.join();
        }
        for (Long value : sums) {
            sum += value;
        }
        return sum;
    }
}
