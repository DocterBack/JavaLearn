package ru.specialist.java.multithreading.concurrent.hw;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Hw3 {

    public static void main(String[] args) throws ExecutionException, InterruptedException, IOException {

//        File dir = new File("d:/my");
//        System.out.println("dir.exists = " + dir.exists());
//        if (!dir.exists()) System.out.println("File doesn't exist");

//        File txtFile = new File(dir, "sample16mb.txt");
//        System.out.println("file.exists = " + txtFile.exists());
//        if (!txtFile.exists()) System.out.println("File doesn't exist");

        long countCommas = countMultiThread("sample16mb.txt", 4);
        System.out.println("Commas are " + countCommas);
    }

    private static String readFromTextFile(String fileName) throws IOException {
        return new String(Files.readString(Path.of(fileName)));

    }

    private static long countMultiThread(String fileName, int nTasks) throws ExecutionException, InterruptedException, IOException {
        ExecutorService pool = Executors.newCachedThreadPool();

        List<Future<Long>> tasks = new ArrayList<>();
        String contents = readFromTextFile(fileName);
        int to = contents.length();
        int stepSize = to/nTasks;
        int r = to % nTasks;

        for (int i = 0; i < nTasks; i++) {
            int a = i*stepSize;
            int b = i*stepSize + stepSize + (i == nTasks - 1 ? r : 0);
            //System.out.println(a);
            tasks.add(pool.submit(() -> count(a, b,contents)));
        }
        pool.shutdown();

        long sum = 0;
        for (Future<Long> task : tasks)
            sum += task.get();

        return sum;
    }

    private static long count(int a, int b, String contents) {
        int chCode = 0;
        long count=0;
        String text = contents.substring(a,b);
        for(int i = 0; i < text.length(); i++) {
            chCode = text.codePointAt(i);
            if (chCode==44)
                count++;
        }
        System.out.println(Thread.currentThread().getName() + " - commas - "+count);
        return count;
    }
}