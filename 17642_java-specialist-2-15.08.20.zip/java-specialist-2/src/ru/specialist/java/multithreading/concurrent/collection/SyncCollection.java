package ru.specialist.java.multithreading.concurrent.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class SyncCollection {

    public static void main(String[] args) throws InterruptedException {
        List<Integer> list =
                new CopyOnWriteArrayList<>();
//                Collections.synchronizedList(new ArrayList<>());
//                new ArrayList<>();

        Runnable listAdd = () -> {
            for (int i = 0; i < 1000; i++) {
                list.add(i);
            }
        };

        Thread t1 = new Thread(listAdd);
        Thread t2 = new Thread(listAdd);

        t1.start();
        t2.start();

        t1.join();
        t2.join();

        System.out.println(list.size());
    }




}
