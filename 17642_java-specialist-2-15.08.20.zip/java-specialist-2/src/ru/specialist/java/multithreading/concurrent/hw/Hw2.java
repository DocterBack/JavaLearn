package ru.specialist.java.multithreading.concurrent.hw;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class Hw2 {

    public static void main(String[] args) throws IOException, ExecutionException, InterruptedException {
        int cnt = 0;
        char vS = ',';
        long t1 = System.currentTimeMillis();
        cnt = searchSimbol2("sample16mb.txt", vS);
        long t2 = System.currentTimeMillis();
        System.out.printf("1. Количество символов \"%s\" - %d шт.  %d ms\n", vS, cnt, t2 - t1);
    }

    private static int searchSimbol2(String fileName, char vSimbol) throws ExecutionException, InterruptedException {
        int cnt = 0;
        ExecutorService pool = Executors.newCachedThreadPool();
        List<Future<Integer>> pools = new ArrayList<>();
        try(BufferedReader objReader = new BufferedReader(new FileReader(fileName))) {
            String strCurrentLine;
            while ((strCurrentLine = objReader.readLine()) != null) {
                pools.add(pool.submit(new Count(strCurrentLine, vSimbol)));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        pool.shutdown();
        for (Future<Integer> future: pools) {
            cnt += future.get();
        }
        return cnt;
    }



    private static  class Count implements Callable<Integer> {
        String textFile;
        char vS;
        int sumValue = 0;

        public Count(String textFile, char vS) {
            this.textFile = textFile;
            this.vS = vS;
        }

        @Override
        public Integer call() throws Exception {
            for (int i = 0; i < textFile.length(); i++) {
                if (textFile.charAt(i) == vS) {
                    sumValue++;
                }
            }
            return sumValue;
        }
    }

}
