package ru.specialist.java.multithreading.concurrent.collection;

import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class SyncMap {

    public static void main(String[] args) throws InterruptedException {
        Map<Integer, String> map =
//                new ConcurrentHashMap<>();
//                Collections.synchronizedMap(new HashMap<>());
                new HashMap<>();

        Runnable mapAdd = () -> {
            for (int i = 0; i < 100000; i++) {
                map.put(i, Thread.currentThread().getName());
            }
        };

        Thread t1 = new Thread(mapAdd);
        Thread t2 = new Thread(mapAdd);

        t1.start();
        t2.start();

        t1.join();
        t2.join();
        
    }
}
