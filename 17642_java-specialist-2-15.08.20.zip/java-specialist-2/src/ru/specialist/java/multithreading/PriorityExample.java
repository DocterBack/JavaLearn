package ru.specialist.java.multithreading;

public class PriorityExample {

    static int n1 = 0;
    static int n2 = 0;

    public static void main(String[] args) throws InterruptedException {

        Thread t0 = new Thread(() -> {
            for (int i = 0; i < 1000000; i++) {
                n1++;
            }
        });

        Thread t1 = new Thread(() -> {
            for (int i = 0; i < 1000000; i++) {
                n2++;
            }
        });

        t0.setPriority(6);
        t1.setPriority(9);

        t0.start();
        t1.start();

        while (n2 < 1000000){
            Thread.sleep(1L);
        }

        System.out.println(n1);
        System.out.println(n2);
    }

}
